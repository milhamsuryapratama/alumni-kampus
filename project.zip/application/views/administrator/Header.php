<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Administrator</title>
  <link rel="icon" href="<?=base_url()?>assets/foto/logo/5cc25ceca1902.64px.ico" type="image/gif"> 
  <link rel="stylesheet" href="<?=base_url()?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/css/AdminLTE.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/css/_all-skins.min.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/css/ionicons.min.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" href="<?=base_url()?>assets/css/jquery-ui.css">
    <link rel="stylesheet"
      href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic" />

    <!-- <link rel="stylesheet" href="<?=base_url()?>assets/js/summernote/summernote-bs4.css">  -->     
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
	


<footer class="main-footer">
	<div class="pull-right hidden-xs">
		<b>P4NJ JEMBER</b>
	</div>
	<strong>Copyright © <script>document.write(new Date().getFullYear());</script> <a href="<?=base_url()?>">P4NJ JEMBER</a>.</strong> All rights
reserved.</strong>
</footer>

</div>
<!-- <script src="<?=base_url()?>assets/js/jquery.min.js"></script> -->
<script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
<script src="<?=base_url()?>assets/js/adminlte.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.slimscroll.min.js"></script>
<script src="<?=base_url()?>assets/js/jquery.dataTables.js"></script>
<script src="<?=base_url()?>assets/js/dataTables.bootstrap.min.js"></script>
<script src="https://use.fontawesome.com/581d5d54d2.js"></script>

<!-- <script>
  $(function () {
    $('#example1').DataTable();
  })
</script> -->

</body>
</html>